import sys
import socket
import threading
from datetime import datetime, timedelta

# Check if the correct number of arguments is provided
if len(sys.argv) != 3:
    print("Usage: python3 server.py server_port number_of_consecutive_failed_attempts")
    sys.exit(1)

# Extract command-line arguments
server_port = int(sys.argv[1])
max_attempts = int(sys.argv[2])

# Check if the port number is valid
if not 1024 <= server_port <= 65535:
    print("Invalid port number. Please use a port number between 1024 and 65535.")
    sys.exit(1)

# Ensure max_attempts is between 1 and 5
if not 1 <= max_attempts <= 5:
    print("The number of consecutive failed attempts must be between 1 and 5.")
    sys.exit(1)

BLOCK_TIME = 10

# Server settings
HOST = '127.0.0.1'  # Localhost

login_failed_attempt = {}
login_unblock_time = {}

# Load credentials from file
def load_credentials():
    with open('credentials.txt', 'r') as f:
        return [line.strip().split() for line in f.readlines()]

# Handle client connection
def handle_client(conn, addr):
    print(f'Connected by {addr}')
    try:
        # Authentication
        credentials = load_credentials()
        max_attempts = 3  # Set the maximum number of attempts

        while True:
            print(login_failed_attempt)
            
            conn.sendall("Enter username: ".encode())
            username = conn.recv(1024).decode().strip()
            print(f"Received username: {username}")

            conn.sendall("Enter password: ".encode())
            password = conn.recv(1024).decode().strip()
            print(f"Received password for {username}")

            attempts = 0
            if username in login_failed_attempt:
                attempts = login_failed_attempt[username]
            
            # Check if user is currently blocked
            if username in login_unblock_time:
                block_time = login_unblock_time[username]
                if datetime.now() < block_time:
                    conn.sendall(b'You are blocked. Please try again later.\n')
                    print(f"User: {username} is blocked.")
                    continue
                else:
                    # Block duration has passed, remove the block
                    login_unblock_time.pop(username)

            # Check credentials
            if [username, password] in credentials:
                login_failed_attempt.pop(username, None)
                login_unblock_time.pop(username, None)
                conn.sendall(b'Welcome! Please input a command: ')
                print(f"User: {username} successfully logged in")
                print("Waiting for user input...")

                # Log the successful login
                with open('userlog.txt', 'a') as log:
                    log.write(f'{addr} logged in as {username}\n')
                
                break
            else:
                attempts += 1
                login_failed_attempt[username] = attempts
                conn.sendall(b'Invalid credentials. Try again.\n')
                print(f"User: {username} unsuccessfully attempted to log in {attempts} times.")

            # Block user after max_attempts
            if attempts >= max_attempts:
                unblock = datetime.now() + timedelta(seconds=10)
                login_unblock_time[username] = (unblock)
                login_failed_attempt.pop(username)
                conn.sendall(b'You are blocked due to multiple failed login attempts.\n')
                print(f"User: {username} has attempted {attempts} time and is blocked until {unblock}.")

        # Main loop for handling commands
        while True:
            conn.sendall(b'Please input a command: ')
            print("Waiting for user input...")
            command = conn.recv(1024).decode().strip()
            if command == '/logout':
                conn.sendall(b'Goodbye!\nPress any key to exit.\n')
                print(f"User: {username} is logged out.")
                break
            else:
                conn.sendall(b'Command not recognized.\n')
                print(f"Invalid command by user: {username}.")

    finally:
        conn.close()

# Create socket and bind to address
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, server_port))
    s.listen()

    print(f'Server is listening on {HOST}:{server_port}')

    # Main server loop
    while True:
        conn, addr = s.accept()
        # Start a new thread for each client
        client_thread = threading.Thread(target=handle_client, args=(conn, addr))
        client_thread.start()
